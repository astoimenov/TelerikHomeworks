﻿namespace CohesionAndCoupling
{
    using System;

    public static class Utils
    {
    }
}
