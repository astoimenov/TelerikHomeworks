﻿using System;

interface ISoundable
{
    void ProduceSound();
}