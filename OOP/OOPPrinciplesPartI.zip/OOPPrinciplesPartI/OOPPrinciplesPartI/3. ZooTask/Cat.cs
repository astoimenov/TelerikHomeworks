﻿using System;

public abstract class Cat : Animal, ISoundable
{
    public Cat()
    {         
    }
}