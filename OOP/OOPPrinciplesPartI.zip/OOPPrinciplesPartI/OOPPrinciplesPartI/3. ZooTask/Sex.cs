﻿using System;

public enum Sex { Male, Female }