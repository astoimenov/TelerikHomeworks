﻿using System;

interface ICommentable
{
    string Comment { get; set; }
}
