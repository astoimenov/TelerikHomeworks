﻿using System;

class Student
{
    public string firstName { get; set; }
    public string lastName { get; set; }
    public uint age { get; set; }
}
