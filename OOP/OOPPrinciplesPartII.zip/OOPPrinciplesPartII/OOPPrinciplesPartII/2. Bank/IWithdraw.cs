﻿using System;

interface IWithdraw
{
    void Withdraw(double amount);
}