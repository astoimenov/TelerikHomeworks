﻿using System;

interface IInterestable
{
    double CalculateInterestAmount(int months);
}