﻿using System;

interface IDepositable
{
    void Deposit(double amount);
}