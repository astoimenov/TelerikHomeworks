﻿using System;

interface IPrintable
{
    void PrintInfo();
}