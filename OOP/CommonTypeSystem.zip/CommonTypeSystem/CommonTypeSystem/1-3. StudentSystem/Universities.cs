﻿using System;

public enum Universities
{
    NewBulgarianUniversity,
    SofiaUniversity,
    UNSS,
    TechnicalUniversity
}