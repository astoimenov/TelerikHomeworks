﻿using System;

public enum Specialties
{
    Electronics,
    Telecommunication,
    Electrotechnics,
    Mathematics,
    Informatics
}