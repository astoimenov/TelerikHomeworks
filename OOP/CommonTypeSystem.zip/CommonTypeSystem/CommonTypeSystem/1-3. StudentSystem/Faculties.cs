﻿using System;

public enum Faculties
{
    ElectronicalFaculty,
    ElectrotechnicalFaculty,
    MathematicsAndInformaticsFaculty
}